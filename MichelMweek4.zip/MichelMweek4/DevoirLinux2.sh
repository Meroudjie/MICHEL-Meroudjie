#!/bin/bash
read -p "Entrez dans le directory" same
find $same -type f -exec md5sum {} + |sort| uniq -w32 -dD | awk '{print $2}'
