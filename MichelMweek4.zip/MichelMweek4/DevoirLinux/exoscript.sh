#!/bin/bash
read -p "Entrer le directory" life
ls $Life > Secret.txt

