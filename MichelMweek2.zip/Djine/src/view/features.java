package view;

public class features
{
 
	public static void display (String m)
	{
		
		System.out.println(m);
		
	}
	
}
