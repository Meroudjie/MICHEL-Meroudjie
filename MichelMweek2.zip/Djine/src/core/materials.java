package core;

public class materials {

	private int matiD;
	private String matname;
	private String mattype;
	
	public materials(int matiD, String matname, String mattype) {
		super();
		this.matiD = matiD;
		this.matname = matname;
		this.mattype = mattype;
	}

	public int getMatiD() {
		return matiD;
	}

	public void setMatiD(int matiD) {
		this.matiD = matiD;
	}

	public String getMatname() {
		return matname;
	}

	public void setMatname(String matname) {
		this.matname = matname;
	}

	public String getMattype() {
		return mattype;
	}

	public void setMattype(String mattype) {
		this.mattype = mattype;
	}

	@Override
	public String toString() {
		return "materials [matiD=" + matiD + ", matname=" + matname + ", mattype=" + mattype + "]";
	}
	
	
	
	
	
}
