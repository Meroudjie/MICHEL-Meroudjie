package core;

public class course 

{

	private int CourseiD;
	private String name;
	private String vision;
	private int time;
	private Professor prof;
	
	
	public course(int courseiD, String name, String vision, int time, Professor prof) {
		super();
		CourseiD = courseiD;
		this.name = name;
		this.vision = vision;
		this.time = time;
		this.prof = prof;
	}
	


	public int getCourseiD() {
		return CourseiD;
	}


	public void setCourseiD(int courseiD) {
		CourseiD = courseiD;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getVision() {
		return vision;
	}


	public void setVision(String vision) {
		this.vision = vision;
	}


	public int getTime() {
		return time;
	}


	public void setTime(int time) {
		this.time = time;
	}


	public Professor getProf() {
		return prof;
	}


	public void setProf(Professor prof) {
		this.prof = prof;
	}


	@Override
	public String toString() {
		return "course [CourseiD=" + CourseiD + ", name=" + name + ", vision=" + vision + ", time=" + time + ", prof="
				+ prof + "]";
	}
	
	
	
	
	
}
