package core;

public class Professor extends Human
{
	//constructeur
	
	private int piD;

	public Professor(int iD, String lname, String fname, String gender, int piD) {
		super(iD, lname, fname, gender);
		this.piD = piD;
	}
	
	//getteurs, setteurs

	public int getPiD() {
		return piD;
	}

	public void setPiD(int piD) {
		this.piD = piD;
	}

	@Override
	public String toString() {
		return  "Professor [piD=" + piD + "]" + super.toString();
	}
	
	

	
	
	
	

}
