package core;
import view.features;
public class Playbook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Human winx = new Human(1,"Michel","Meroudjie","Feminin");
		features.display(winx.toString());
		Professor Delva  = new Professor (2, "Delva", "Basile", "masculin", 1);
		String info = Delva.toString();
		features.display(info);
		students Paulin = new students (3, "Paulin", "Luckny", "Feminin", 4);
		String info_2 = Paulin.toString();
		features.display(info_2);
		
		course maths = new course(2, "Mathematiques", "reussir", 200, Delva);
		features.display(maths.toString());
		
		materials livre = new materials (56, "Vive les maths", "livre");
	}

}
