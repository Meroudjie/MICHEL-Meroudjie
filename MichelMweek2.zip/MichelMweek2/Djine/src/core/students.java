package core;

public class students extends Human

{
	private int StuiD ;

	public students(int iD, String lname, String fname, String gender, int stuiD) {
		super(iD, lname, fname, gender);
		StuiD = stuiD;
	}

	public int getStuiD() {
		return StuiD;
	}

	public void setStuiD(int stuiD) {
		StuiD = stuiD;
	}

	@Override
	public String toString() {
		return "students [StuiD=" + StuiD + "]" + super.toString();
	}
	
	
}
